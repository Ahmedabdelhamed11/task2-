#include <stdio.h>

int main() {
    int A, B, C, D;
    int X;
    
    printf("Enter four numbers: ");
    scanf("%d %d %d %d", &A, &B, &C, &D);
    
    X = (A * B) - (C * D);
    
    printf("Result: %d\n", X);
    
    return 0;
}