#include <stdio.h>
int main() {
    int A, B, C;
    
    printf("Enter three numbers: ");
    scanf("%d %d %d", &A, &B, &C);
    
    int minimum = A;
    int maximum = A;
    
    if (B < minimum) {
        minimum = B;
    }
    
    if (C < minimum) {
        minimum = C;
    }
    
    if (B > maximum) {
        maximum = B;
    }
    
    if (C > maximum) {
        maximum = C;
    }
    
    printf("Minimum number: %d\n", minimum);
    printf("Maximum number: %d\n", maximum);
    
    return 0;
}
#